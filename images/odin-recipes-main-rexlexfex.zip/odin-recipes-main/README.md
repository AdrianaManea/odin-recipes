# odin-recipes
Where Odin's delicious recipes are presented as peace offerings!

At the end of this project, I will have demonstrated my ability to appease the dreaded Moskstraumen through culinary prowess. May the mighty windstorm spare our daring vessels. 
